#!/usr/bin/env bash
set -u
LABDIR="$(cd "$(dirname "$0")" && pwd)"
LOGFILE="$LABDIR/LinuxMDETest-$(date +%Y%m%d-%H%M%S).log"

run_test() {
  local script="$1"
  echo
echo "----------------------------------------"
  echo "Running: $script"
  echo "----------------------------------------"
  cd "$LABDIR" || return 1
  if [[ ! -f "$LABDIR/$script" ]]; then echo "[SKIP] $script not found."; return 0; fi
  chmod +x "$LABDIR/$script"
  "$LABDIR/$script"
  local rc=$?
  if [[ $rc -eq 0 ]]; then echo "[COMPLETE] $script"; else echo "[WARNING] $script returned exit code $rc"; fi
  return 0
}

{
  echo "========================================"
  echo " Microsoft Defender for Endpoint Linux Lab Suite"
  echo "========================================"
  echo "Lab directory: $LABDIR"
  run_test MDEHealthCheck.sh
  run_test EICARTest.sh
  run_test BehaviorMonitoringTest.sh
  run_test ReconTest.sh
  run_test EDRDetectionTest.sh
  echo
echo "========================================"
  echo " Suite complete"
  echo "========================================"
} 2>&1 | tee "$LOGFILE"

echo "Log: $LOGFILE"
