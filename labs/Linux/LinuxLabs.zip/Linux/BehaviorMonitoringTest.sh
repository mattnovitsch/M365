#!/usr/bin/env bash
set -u
TESTDIR="/tmp/mde-behavior-test"
cleanup() { rm -rf "$TESTDIR"; }
trap cleanup EXIT
mkdir -p "$TESTDIR"

echo "========================================"
echo " MDE Linux Behavior Telemetry Test"
echo "========================================"

cat > "$TESTDIR/test.sh" <<'EOF'
#!/usr/bin/env bash
FILE="/tmp/mde-behavior-test/test-data.txt"
echo "MDE behavior monitoring lab test" > "$FILE"
cp "$FILE" "${FILE}.copy"
cat "${FILE}.copy" >/dev/null
rm -f "${FILE}.copy"
EOF
chmod +x "$TESTDIR/test.sh"
"$TESTDIR/test.sh"

bash -c 'sleep 1 &' || true
bash -c 'id >/dev/null' || true
bash -c 'uname -a >/dev/null' || true

touch "$TESTDIR/file1"
cp "$TESTDIR/file1" "$TESTDIR/file2"
mv "$TESTDIR/file2" "$TESTDIR/file3"
rm -f "$TESTDIR/file3"

echo "[COMPLETE] Benign process/file behavior generated. This test does not guarantee an alert."
echo "Review the device timeline and relevant Advanced Hunting telemetry."
