#!/usr/bin/env bash
set -u

echo "========================================"
echo " Linux Reconnaissance Telemetry Test"
echo "========================================"

run() { echo; echo "[TEST] $1"; shift; "$@" >/dev/null 2>&1 || true; }
run "Current identity" id
run "Current user" whoami
run "Host information" hostname
run "Kernel information" uname -a
run "Logged-in users" who
run "User account enumeration" getent passwd
run "Group enumeration" getent group

command -v ip >/dev/null 2>&1 && run "Network interfaces" ip addr
command -v ip >/dev/null 2>&1 && run "Routing table" ip route
command -v ss >/dev/null 2>&1 && run "Network sockets" ss -tulnp
run "Running processes" ps aux

if command -v rpm >/dev/null 2>&1; then run "Installed RPM packages" rpm -qa; fi
if command -v dpkg >/dev/null 2>&1; then run "Installed DEB packages" dpkg -l; fi

run "SSH configuration discovery" find /etc/ssh -type f
run "Scheduled-job discovery" find /etc -maxdepth 2 -type f -name 'cron*'

echo
echo "[COMPLETE] Benign discovery activity generated. An alert is not guaranteed or expected solely because these commands ran."
echo "Review the Defender device timeline and relevant Advanced Hunting telemetry."
