#!/usr/bin/env bash
set -u
TESTDIR="/tmp/mde-linux-edr-test"
ZIPFILE="$TESTDIR/MDE-Linux-EDR-DIY.zip"
mkdir -p "$TESTDIR"

echo "========================================"
echo " Microsoft Defender Linux EDR Detection Test"
echo "========================================"

for cmd in mdatp curl unzip; do
  if ! command -v "$cmd" >/dev/null 2>&1; then echo "[FAIL] Required command not found: $cmd"; exit 1; fi
done

echo "Defender health: $(mdatp health --field healthy 2>/dev/null || echo unknown)"
echo "Downloading Microsoft's MDE Linux EDR DIY package..."
if ! curl -fL --connect-timeout 15 --max-time 120 -o "$ZIPFILE" https://aka.ms/MDE-Linux-EDR-DIY; then
  echo "[FAIL] Could not download the Microsoft EDR test package."
  exit 1
fi

unzip -oq "$ZIPFILE" -d "$TESTDIR/extracted"
SCRIPT=$(find "$TESTDIR/extracted" -type f -name 'mde_linux_edr_diy.sh' -print -quit)
if [[ -z "${SCRIPT:-}" ]]; then
  echo "[FAIL] mde_linux_edr_diy.sh was not found in the package."
  exit 1
fi

chmod +x "$SCRIPT"
echo "Running: $SCRIPT"
"$SCRIPT"
RESULT=$?

echo
echo "Review the Defender device timeline and Alerts after the test."
exit "$RESULT"
