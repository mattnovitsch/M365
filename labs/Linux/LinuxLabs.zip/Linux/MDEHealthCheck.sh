#!/usr/bin/env bash
set -u

echo "========================================"
echo " Microsoft Defender for Endpoint - Linux Health"
echo "========================================"

if ! command -v mdatp >/dev/null 2>&1; then
  echo "[FAIL] Microsoft Defender for Endpoint (mdatp) is not installed or not in PATH."
  exit 1
fi

fields=(
  app_version
  healthy
  real_time_protection_enabled
  behavior_monitoring
  cloud_enabled
  definitions_status
  definitions_version
  edr_client_version
  edr_machine_id
  health_issues
)

for field in "${fields[@]}"; do
  printf '%-35s : ' "$field"
  mdatp health --field "$field" 2>/dev/null || echo "Unavailable"
done

echo
echo "Full health output:"
mdatp health
