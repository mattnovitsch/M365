#!/usr/bin/env bash
set -u
TESTDIR="/tmp/mde-eicar-test"
TESTFILE="$TESTDIR/eicar.com.txt"

cleanup() { rm -rf "$TESTDIR"; }
trap cleanup EXIT
mkdir -p "$TESTDIR"

echo "========================================"
echo " MDE Linux EICAR Antivirus Test"
echo "========================================"

if ! command -v mdatp >/dev/null 2>&1; then echo "[FAIL] mdatp not found."; exit 1; fi
if ! command -v curl >/dev/null 2>&1; then echo "[FAIL] curl not found."; exit 1; fi

echo "Real-time protection:"
mdatp health --field real_time_protection_enabled || true

echo
echo "Downloading the standard EICAR antivirus test file. Defender may remove/quarantine it immediately."
curl -fL --connect-timeout 15 --max-time 60 -o "$TESTFILE" https://secure.eicar.org/eicar.com.txt || true
sleep 3

if [[ -f "$TESTFILE" ]]; then
  echo "[INFO] EICAR file still exists. Review Defender configuration and threat history."
else
  echo "[PASS/INFO] EICAR file is no longer present. Confirm disposition in the Defender threat list/portal."
fi

echo
echo "Local Defender threat list:"
mdatp threat list || true
