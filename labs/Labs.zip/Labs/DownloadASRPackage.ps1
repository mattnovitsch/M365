﻿# Define the URL and the destination path
$url = "https://demo.wd.microsoft.com/Content/ASR_SetupScript.zip"
$outputPath = "C:\MDETest\ASR_SetupScript.zip"

$path = "C:\MDETest\"

if (-not (Test-Path -Path $path)) {
    New-Item -Path "C:\" -Name "MDETest" -ItemType "Directory"
    Write-Output "Directory created at $path"
} else {
    Write-Output "Directory already exists at $path"
}

# Download the file
Invoke-WebRequest -Uri $url -OutFile $outputPath