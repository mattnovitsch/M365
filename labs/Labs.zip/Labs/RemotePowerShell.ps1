﻿# Define the URL and the destination path
$url = "https://download.sysinternals.com/files/PSTools.zip"
$outputPath = "C:\MDETest\PSTools.zip"

$path = "C:\MDETest\"

if (-not (Test-Path -Path $path)) {
    New-Item -Path "C:\" -Name "MDETest" -ItemType "Directory"
    Write-Output "Directory created at $path"
} else {
    Write-Output "Directory already exists at $path"
}


if (-not (Test-Path -Path $outputPath)) {
    # Download the file
    Invoke-WebRequest -Uri $url -OutFile $outputPath
    
    # Unzipping a file
    Expand-Archive -Path "C:\MDETest\PSTools.zip" -DestinationPath "C:\MDETest"
} else {
    Write-Output "File already exists at $path"
}

# Transfer recon file dc
$Remotepath = $env:LOGONSERVER+"\c$\tools\"
Copy-Item -Path "C:\Tools\Labs\Recon.ps1" -Destination $Remotepath

#remote execution of file
$RemoteFileExe = $Remotepath+"Recon.ps1"

#Run file
CD C:\MDETest
#.\PSExec.exe -s -i $env:LOGONSERVER powershell.exe -accepteula
.\PSExec.exe -s $env:LOGONSERVER Powershell -ExecutionPolicy Bypass -File $RemoteFileExe -accepteula
