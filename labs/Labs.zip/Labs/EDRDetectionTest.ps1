﻿# EDRDetectionTest.ps1
# Microsoft Defender for Endpoint benign EDR onboarding/reporting test
# Run from an elevated PowerShell session on an onboarded lab device.

[CmdletBinding()]
param()

$LabPath = 'C:\Tools\Labs'
$TestPath = 'C:\test-WDATP-test'
$TestFile = Join-Path $TestPath 'invoice.exe'
$TestUrl  = 'http://127.0.0.1/1.exe'

# Always return to the lab directory before executing the test.
Set-Location -Path $LabPath -ErrorAction Stop

Write-Host 'Starting Microsoft Defender for Endpoint EDR detection test...' -ForegroundColor Cyan

# The Microsoft test pattern expects the local device to be listening on TCP 80.
$PortTest = Test-NetConnection -ComputerName 127.0.0.1 -Port 80 -InformationLevel Quiet -WarningAction SilentlyContinue
if (-not $PortTest) {
    Write-Warning 'TCP port 80 on 127.0.0.1 is not listening. This is expected on many systems, but the official EDR test download will not complete.'
}

try {
    New-Item -Path $TestPath -ItemType Directory -Force -ErrorAction Stop | Out-Null

    # This is Microsoft's benign EDR detection-test pattern.
    # Errors are intentionally suppressed so the activity sequence can complete.
    $PreviousErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'

    (New-Object System.Net.WebClient).DownloadFile($TestUrl, $TestFile)
    Start-Process -FilePath $TestFile

    $ErrorActionPreference = $PreviousErrorActionPreference
    Write-Host 'EDR test sequence completed. Check the Microsoft Defender portal for the resulting alert.' -ForegroundColor Green
}
catch {
    $ErrorActionPreference = $PreviousErrorActionPreference
    Write-Warning "EDR test sequence encountered an error: $($_.Exception.Message)"
}
finally {
    Set-Location -Path $LabPath -ErrorAction SilentlyContinue
}
