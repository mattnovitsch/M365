﻿cd C:\Tools\Labs
.\DownloadEICARFile.ps1
.\DownloadPUAFile.ps1
.\NetworkProtection.ps1
.\ORADAD.ps1
.\Recon.ps1
.\RemotePowerShell.ps1
.\RemoveDefender.ps1
.\SuspiciousPowershell.ps1
.\AMSITest.ps1