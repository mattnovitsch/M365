﻿# Run-All-MDELabTests.ps1

$LabPath = "C:\Tools\Labs"

$Tests = @(
    "DownloadEICARFile.ps1"
    "DownloadPUAFile.ps1"
    "NetworkProtection.ps1"
    "ORADAD.ps1"
    "Recon.ps1"
    "RemotePowerShell.ps1"
    "SuspiciousPowershell.ps1"
    "AMSITest.ps1"
    "BehaviorMonitoring.ps1"
    "EDRDetectionTest.ps1"
    "Obfuscated.ps1"
    "BlockProcessCreationfromWMI.ps1"
    "ASR-LSASS.ps1"
    "Ransomware.ps1"
)

$Results = @()

foreach ($Test in $Tests) {

    try {
        # Always return to the lab folder before each test
        Set-Location $LabPath -ErrorAction Stop

        Write-Host ""
        Write-Host "====================================" -ForegroundColor Cyan
        Write-Host "Running: $Test" -ForegroundColor Yellow
        Write-Host "====================================" -ForegroundColor Cyan

        $StartTime = Get-Date

        & ".\$Test"

        $Results += [PSCustomObject]@{
            Test      = $Test
            Status    = "Success"
            StartTime = $StartTime
            EndTime   = Get-Date
            Error     = ""
        }

        Write-Host "$Test completed successfully" -ForegroundColor Green
    }
    catch {
        $Results += [PSCustomObject]@{
            Test      = $Test
            Status    = "Failed"
            StartTime = $StartTime
            EndTime   = Get-Date
            Error     = $_.Exception.Message
        }

        Write-Warning "$Test failed: $($_.Exception.Message)"
    }

    # Always return to the lab folder
    Set-Location $LabPath -ErrorAction SilentlyContinue

    # Pause between tests so alerts have time to generate
    Write-Host "Waiting 20 seconds before next test..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 20
}

# Export results

$Report = Join-Path $LabPath "MDE-LabResults.csv"

$Results | Export-Csv -Path $Report -NoTypeInformation

Write-Host ""
Write-Host "====================================" -ForegroundColor Green
Write-Host "All simulations complete." -ForegroundColor Green
Write-Host "Results: $Report" -ForegroundColor Green
Write-Host "====================================" -ForegroundColor Green