﻿# Define the URL and the destination path
$url = "https://www.eicar.org/download/eicar-com-2/?wpdmdl=8842&refresh=686bb9ed4b7071751890413"
$outputPath = "C:\MDETest\eicar.com"

$path = "C:\MDETest\"

if (-not (Test-Path -Path $path)) {
    New-Item -Path "C:\" -Name "MDETest" -ItemType "Directory"
    Write-Output "Directory created at $path"
} else {
    Write-Output "Directory already exists at $path"
}

# Download the file
Invoke-WebRequest -Uri $url -OutFile $outputPath