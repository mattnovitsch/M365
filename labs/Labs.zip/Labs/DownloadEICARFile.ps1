﻿# Define the URL and the destination path
$url = "https://secure.eicar.org/eicar_com2.zip"
$outputPath = "C:\MDETest\eicar.com"

$path = "C:\MDETest\"

if (-not (Test-Path -Path $path)) {
    New-Item -Path "C:\" -Name "MDETest" -ItemType "Directory"
    Write-Output "Directory created at $path"
} else {
    Write-Output "Directory already exists at $path"
}

# Download the file
Invoke-WebRequest -Uri $url -OutFile $outputPath