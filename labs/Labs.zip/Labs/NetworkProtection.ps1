﻿$url = "https://smartscreentestratings2.net/"

Invoke-WebRequest -Uri $url

Start-Process "msedge.exe" -ArgumentList $url
