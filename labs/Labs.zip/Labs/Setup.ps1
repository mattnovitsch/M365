﻿############Task 1 NetworkProtection
# Define the trigger (daily at 1:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 1:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\NetworkProtection.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "NetworkProtection" -Trigger $trigger -Action $action -Settings $settings -Description "Runs NetworkProtection.ps1 daily at 1:00 AM"
############End of task 1 processes

############Task 2 DownloadEICARFile
# Define the trigger (daily at 2:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 2:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\DownloadEICARFile.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "DownloadEICARFile" -Trigger $trigger -Action $action -Settings $settings -Description "Runs DownloadEICARFile.ps1 daily at 2:00 AM"
############End of task 2 processes

############Task 3 DownloadPUAFile
# Define the trigger (daily at 3:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 3:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\DownloadPUAFile.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "DownloadPUAFile" -Trigger $trigger -Action $action -Settings $settings -Description "Runs DownloadPUAFile.ps1 daily at 3:00 AM"
############End of task 3 processes

############Task 4 ORADAD
# Define the trigger (daily at 4:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 4:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\ORADAD.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "ORADAD" -Trigger $trigger -Action $action -Settings $settings -Description "Runs ORADAD.ps1 daily at 4:00 AM"
############End of task 4 processes

############Task 5 Recon
# Define the trigger (daily at 5:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 5:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\Recon.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "Recon" -Trigger $trigger -Action $action -Settings $settings -Description "Runs Recon.ps1 daily at 5:00 AM"
############End of task 5 processes


############Task 6 RemotePowerShell
# Define the trigger (daily at 6:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 6:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\RemotePowerShell.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "RemotePowerShell" -Trigger $trigger -Action $action -Settings $settings -Description "Runs RemotePowerShell.ps1 daily at 6:00 AM"
############End of task 6 processes

############Task 7 RemoveDefender
# Define the trigger (daily at 7:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 7:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\RemoveDefender.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "RemoveDefender" -Trigger $trigger -Action $action -Settings $settings -Description "Runs RemoveDefender.ps1 daily at 7:00 AM"
############End of task 7 processes

############Task 8 SuspiciousPowershell
# Define the trigger (daily at 8:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 8:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\SuspiciousPowershell.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "SuspiciousPowershell" -Trigger $trigger -Action $action -Settings $settings -Description "Runs SuspiciousPowershell.ps1 daily at 8:00 AM"
############End of task 8 processes

############Task 9 AMSITest
# Define the trigger (daily at 9:00 AM)
$trigger = New-ScheduledTaskTrigger -Daily -At 9:00AM

# Define the action (run a PowerShell script)
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -File C:\Tools\Labs\AMSITest.ps1"

# Define the task settings (optional)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

# Register the scheduled task
Register-ScheduledTask -TaskName "AMSI" -Trigger $trigger -Action $action -Settings $settings -Description "Runs AMSITest.ps1 daily at 9:00 AM"
############End of task 9 processes