# Ensure demo folder exists
New-Item -Path "C:\Tools\Labs" -ItemType Directory -Force | Out-Null

# Download CFA test tool
$Tool = "C:\Tools\Labs\CFAtool.exe"
Invoke-WebRequest `
    -Uri "https://demo.wd.microsoft.com/Content/CFAtool.exe" `
    -OutFile $Tool

# Execute the test
Start-Process -FilePath $Tool -Wait

Write-Host "CFA ransomware simulation completed."