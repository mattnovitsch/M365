﻿##Recon Attack
net user /domain   net group /domain  net group "Domain Admins" /domain  net group "Enterprise Admins" /domain  net group "Schema Admins" /domain  