﻿# Define the URL and the destination path
$url = "https://github.com/ANSSI-FR/ORADAD/releases/download/3.4.212/ORADAD.zip"
$outputPath = "C:\MDETest\ORADAD.zip"

$path = "C:\MDETest\"

if (-not (Test-Path -Path $path)) {
    New-Item -Path "C:\" -Name "MDETest" -ItemType "Directory"
    Write-Output "Directory created at $path"
} else {
    Write-Output "Directory already exists at $path"
}

# Download the file
Invoke-WebRequest -Uri $url -OutFile $outputPath

# Unzipping a file
Expand-Archive -Path "C:\MDETest\ORADAD.zip" -DestinationPath "C:\MDETest"

#Run file
CD C:\MDETest
.\Oradad.exe