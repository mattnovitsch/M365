﻿$amsiTest = [Ref].Assembly.GetType('System.Management.Automation.AmsiUtils')
if ($amsiTest) {
    $amsiEnabled = $amsiTest.GetField('amsiInitFailed', 'NonPublic,Static')
    if ($amsiEnabled) {
        $status = $amsiEnabled.GetValue($null)
        if ($status -eq $false) {
            "AMSI is enabled and initialized."
        } else {
            "AMSI is disabled or failed to initialize."
        }
    }
} else {
    "AMSI support not found in this context."
}