﻿$url = "http://amtso.eicar.org/PotentiallyUnwanted.exe"
$outputPath = "C:\MDETest\PotentiallyUnwanted.exe"

Invoke-WebRequest -uri $url -OutFile $outputPath